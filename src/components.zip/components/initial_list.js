const INITIAL_LIST = [
    {
      id: '1',
      color: 'blue',
      number: 0,
      cssClassName: "card release-1"
    },
    {
      id: '2',
      color: 'grey',
      number: 0,
      cssClassName: "card release-2"
    },
    {
        id: '3',
        color: 'black',
        number: 0,
        cssClassName: "card release-3"
    },
    {
        id: '4',
        color: 'white',
        number: 0,
        cssClassName: "card release-4"
    },
    {
        id: '5',
        color: 'purple',
        number: 0,
        cssClassName: "card release-5"
    },
  ];

  export default INITIAL_LIST